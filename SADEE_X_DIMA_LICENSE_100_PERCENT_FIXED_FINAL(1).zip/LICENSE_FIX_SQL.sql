-- SADEE X DIMA secure license validation
-- Run this ONCE in Supabase SQL Editor.
-- This avoids exposing the whole license_keys table to the Android app.

CREATE OR REPLACE FUNCTION public.validate_license(
    p_username text,
    p_key_code text,
    p_device_id text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    lic public.license_keys%ROWTYPE;
    used_devices integer := 0;
    same_device boolean := false;
BEGIN
    SELECT *
    INTO lic
    FROM public.license_keys
    WHERE lower(trim(username)) = lower(trim(p_username))
      AND trim(key_code) = trim(p_key_code)
    ORDER BY created_at DESC NULLS LAST
    LIMIT 1;

    IF NOT FOUND THEN
        RETURN jsonb_build_object('valid', false, 'reason', 'invalid');
    END IF;

    IF lower(coalesce(lic.status,'')) <> 'active' THEN
        RETURN jsonb_build_object(
            'valid', false,
            'reason', lower(coalesce(lic.status,'invalid'))
        );
    END IF;

    IF lic.expires_at IS NOT NULL
       AND lic.expires_at <= now() THEN
        RETURN jsonb_build_object('valid', false, 'reason', 'expired');
    END IF;

    IF to_regclass('public.license_devices') IS NOT NULL THEN
        SELECT EXISTS (
            SELECT 1
            FROM public.license_devices d
            WHERE d.license_key_id = lic.id
              AND d.device_id = p_device_id
        )
        INTO same_device;

        SELECT count(*)
        INTO used_devices
        FROM public.license_devices d
        WHERE d.license_key_id = lic.id;

        IF NOT same_device
           AND coalesce(lic.device_limit,1) > 0
           AND used_devices >= coalesce(lic.device_limit,1) THEN
            RETURN jsonb_build_object(
                'valid', false,
                'reason', 'device_limit'
            );
        END IF;
    END IF;

    RETURN jsonb_build_object(
        'valid', true,
        'reason', 'ok',
        'id', lic.id,
        'username', lic.username,
        'key_code', lic.key_code,
        'status', lic.status,
        'expires_at', lic.expires_at,
        'device_limit', lic.device_limit,
        'duration_days', lic.duration_days
    );
END;
$$;

GRANT EXECUTE ON FUNCTION public.validate_license(text,text,text)
TO anon, authenticated;

NOTIFY pgrst, 'reload schema';
